#define NMAX 100
struct Mystruct{
int lunghezza_riga;
float elementi_doppione[NMAX];
int indice_di_riga;

};
int main()
{


	
	}
