#include <stdio.h>
#include <string.h>

#define NMAX 200

struct mystruct {
 int linea;
 int token;
 char str[200];
 int value;
};

int main()
{
	
	}
